package g1.ServiceDemo;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

public class MainProg {
	public static void main(String[] args) {
		
		HelloServiceLocator obj = new HelloServiceLocator();
		try {
			Hello hello = obj.getHello();
			System.out.println(hello.hello());
			System.out.println(hello.trainer());
			System.out.println(hello.company());
		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
