/**
 * Hello.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package g1.ServiceDemo;

public interface Hello extends java.rmi.Remote {
    public java.lang.String hello() throws java.rmi.RemoteException;
    public java.lang.String trainer() throws java.rmi.RemoteException;
    public java.lang.String company() throws java.rmi.RemoteException;
}
