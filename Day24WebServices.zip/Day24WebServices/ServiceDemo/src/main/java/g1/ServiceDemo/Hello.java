package g1.ServiceDemo;

public class Hello {

	public String hello()
	{
		return "Welcome to Web Services";
	}
	public String company()
	{
		return "Infinite Computer Solutions";
	}
	public String trainer() {
		return "Trainer is Prasanna";
	}
}
