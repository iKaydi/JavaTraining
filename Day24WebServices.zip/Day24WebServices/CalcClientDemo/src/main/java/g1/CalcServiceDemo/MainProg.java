package g1.CalcServiceDemo;

import java.rmi.RemoteException;
import java.util.Scanner;

import javax.xml.rpc.ServiceException;

public class MainProg {

	public static void main(String[] args) {
		int a,b;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number 1");
		a = sc.nextInt();
		System.out.println("Enter number 2");
		b = sc.nextInt();
		
		CalcServiceLocator obj = new CalcServiceLocator();
		try {
			Calc calc = obj.getCalc();
			System.out.println(calc.sum(a, b));
			System.out.println(calc.sub(a, b));
			System.out.println(calc.mul(a, b));
			System.out.println(calc.div(a, b));

		} catch (ServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
