package g1.CalcServiceDemo;

public class App {

  public static void main(String[] args) {
    System.out.println("Hello World!");
  }

}
